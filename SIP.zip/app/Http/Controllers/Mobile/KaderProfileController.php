<?php

namespace App\Http\Controllers\Mobile;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules;
use Illuminate\Validation\Rule;
use Illuminate\View\View;

class KaderProfileController extends Controller
{
    public function __invoke($token): View
    {
        return view('mobile.kaderprofile',[
            'pengguna' => User::where('token',$token)->first(),
            'token' => $token
        ]);
    }
}
