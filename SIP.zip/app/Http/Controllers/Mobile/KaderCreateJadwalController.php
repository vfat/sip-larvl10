<?php

namespace App\Http\Controllers\Mobile;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\balita;
use App\Models\User;
use App\Models\jadwal;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules;

class KaderCreateJadwalController extends Controller
{
    /**
     * Handle the incoming request.
     */
    public function __invoke(Request $request): RedirectResponse
    {
        $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'tanggal' => ['required'],
        ]);

       
        
        $hasil=jadwal::updateOrCreate([
            'name' => $request->name,
            'tanggal' => $request->tanggal,
 
        ]);
        // echo json_encode($hasil);
        

        return redirect()->back();
    }
}
