<?php if (isset($component)) { $__componentOriginalf1e11f6ffe4d9c13604c21368fa53602 = $component; } ?>
<?php $component = App\View\Components\MobileLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('mobile-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\MobileLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<div class="min-h-screen flex flex-col sm:justify-center items-center pt-6 sm:pt-0 bg-gray-100 dark:bg-gray-900">


<!-- <div class="w-full sm:max-w-md mt-6 px-6 py-4 bg-white dark:bg-gray-800 shadow-md overflow-hidden sm:rounded-lg"> -->

<div class="grid grid-flow-row-dense grid-cols-2 gap-2">
  <div><a href="<?php echo e(route('mobile.balita', $token)); ?>" class="btn btn-info btn-wide btn-xs sm:btn-sm md:btn-md lg:btn-lg">Profil Balita</a></div>
  <div><a href="<?php echo e(route('mobile.balita', $token)); ?>" class="btn btn-success btn-wide btn-xs sm:btn-sm md:btn-md lg:btn-lg">Tumbuh Kembang</a></div>
  <div><a href="<?php echo e(route('mobile.balita', $token)); ?>" class="btn btn-warning btn-success btn-wide btn-xs sm:btn-sm md:btn-md lg:btn-lg">QR Code</a></div>
</div>


<!-- </div> -->
</div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf1e11f6ffe4d9c13604c21368fa53602)): ?>
<?php $component = $__componentOriginalf1e11f6ffe4d9c13604c21368fa53602; ?>
<?php unset($__componentOriginalf1e11f6ffe4d9c13604c21368fa53602); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\testing\larvl10\SIP\resources\views/mobile/dashboardortu.blade.php ENDPATH**/ ?>