<?php if (isset($component)) { $__componentOriginalf1e11f6ffe4d9c13604c21368fa53602 = $component; } ?>
<?php $component = App\View\Components\MobileLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('mobile-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\MobileLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <div class="overflow-x-auto">                         

                        <table class="table table-zebra">
                            <!-- head -->
                            <thead>
                                <tr>
                                    <th></th>
                                    <th>Nama</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php ($no=1); ?>
                            <?php $__currentLoopData = $balita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bayi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                                <tr>
                                    <th><?php echo e($no); ?></th>
                                    <td><?php echo e($bayi->nama); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('mobile.balitadetail', [$bayi->id, $token])); ?>" class="btn btn-info">Detail</a>
                                    </td>
                                </tr>
                                <?php ($no++); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php echo e($balita->links()); ?>

                    </div>
                </div>
            </div>





        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf1e11f6ffe4d9c13604c21368fa53602)): ?>
<?php $component = $__componentOriginalf1e11f6ffe4d9c13604c21368fa53602; ?>
<?php unset($__componentOriginalf1e11f6ffe4d9c13604c21368fa53602); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\testing\larvl10\SIP\resources\views/mobile/profilebalita.blade.php ENDPATH**/ ?>